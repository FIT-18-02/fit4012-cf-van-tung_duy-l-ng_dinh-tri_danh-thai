# crypto_utils.py
# Thư viện các hàm mã hóa, ký, kiểm tra toàn vẹn, thao tác DB

import sqlite3
from Crypto.Cipher import DES3, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.Random import get_random_bytes

# Tên database
DB_NAME = 'chat_secure.db'

# Bổ sung dữ liệu để đủ block 8 byte (DES3 yêu cầu)
def pad(data):
    pad_len = 8 - len(data) % 8
    return data + bytes([pad_len]) * pad_len

# Bỏ padding sau khi giải mã
def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]

# Mã hóa TripleDES
def encrypt_triple_des(key, plaintext):
    iv = get_random_bytes(8)  # vector khởi tạo
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(plaintext))
    return iv, ciphertext

# Giải mã TripleDES
def decrypt_triple_des(key, iv, ciphertext):
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    plaintext = unpad(cipher.decrypt(ciphertext))
    return plaintext

# Tính hash SHA-256 cho IV + ciphertext
def sha256_hash(iv, ciphertext):
    h = SHA256.new(iv + ciphertext)
    return h.hexdigest()

# Mã hóa dữ liệu bằng RSA OAEP
def encrypt_with_rsa(public_key_pem, data):
    key = RSA.import_key(public_key_pem)
    cipher = PKCS1_OAEP.new(key, hashAlgo=SHA256)
    encrypted = cipher.encrypt(data)
    return encrypted

# Giải mã dữ liệu bằng RSA OAEP
def decrypt_with_rsa(private_key_pem, data):
    key = RSA.import_key(private_key_pem)
    cipher = PKCS1_OAEP.new(key, hashAlgo=SHA256)
    decrypted = cipher.decrypt(data)
    return decrypted

# Ký dữ liệu bằng private key
def sign_data(private_key_pem, data):
    key = RSA.import_key(private_key_pem)
    h = SHA256.new(data)
    signature = pkcs1_15.new(key).sign(h)
    return signature

# Xác thực chữ ký
def verify_signature(public_key_pem, data, signature):
    key = RSA.import_key(public_key_pem)
    h = SHA256.new(data)
    try:
        pkcs1_15.new(key).verify(h, signature)
        return True
    except (ValueError, TypeError):
        return False

# ================== DATABASE ==================

# Tạo bảng messages nếu chưa có
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS messages
    (id INTEGER PRIMARY KEY AUTOINCREMENT,
     iv TEXT,
     cipher TEXT,
     hash TEXT,
     sig TEXT)
    ''')
    conn.commit()
    conn.close()

# Lưu message vào DB
def save_message_to_db(iv, cipher, hash_val, sig):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO messages (iv, cipher, hash, sig) VALUES (?, ?, ?, ?)",
              (iv, cipher, hash_val, sig))
    conn.commit()
    conn.close()

# Đọc message từ DB theo id
def read_message_from_db(msg_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT iv, cipher, hash, sig FROM messages WHERE id=?", (msg_id,))
    row = c.fetchone()
    conn.close()
    return row
