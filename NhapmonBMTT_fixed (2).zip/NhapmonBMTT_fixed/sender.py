import base64
import time
from Crypto.Random import get_random_bytes
from Crypto.Cipher import DES3
import cryptoUtils as crypto

# Load các khóa
sender_priv = open('sender_private.pem', 'rb').read()
receiver_pub = open('receiver_public.pem', 'rb').read()

# Khởi tạo DB
crypto.init_db()

# Handshake
print("Hello!")
print("Ready!")

# Tạo khóa TripleDES
triple_des_key = DES3.adjust_key_parity(get_random_bytes(24))

# Ký thông tin xác thực
sender_id = b"user_sender"
timestamp = str(time.time()).encode()
auth_info = sender_id + b"|" + timestamp
signed_info = crypto.sign_data(sender_priv, auth_info)

# Mã hóa khóa TripleDES
encrypted_3des_key = crypto.encrypt_with_rsa(receiver_pub, triple_des_key)

with open("encrypted_3des_key.bin", "wb") as f:
    f.write(encrypted_3des_key)

# Mã hóa nội dung message
message = b"Hello, this is a secret message!"
iv, ciphertext = crypto.encrypt_triple_des(triple_des_key, message)

# Tạo hash
hash_val = crypto.sha256_hash(iv, ciphertext)

# Ký ciphertext
message_signature = crypto.sign_data(sender_priv, ciphertext)

# Lưu message vào DB
crypto.save_message_to_db(
    base64.b64encode(iv).decode(),
    base64.b64encode(ciphertext).decode(),
    hash_val,
    base64.b64encode(message_signature).decode()
)

print("Đã gửi message và lưu vào DB!")