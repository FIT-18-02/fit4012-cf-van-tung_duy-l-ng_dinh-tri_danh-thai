# keygen.py
# Sinh cặp khóa RSA cho bên gửi và bên nhận

from Crypto.PublicKey import RSA

def generate_rsa_keypair(filename_prefix):
    # Sinh khóa 2048 bit
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()

    # Lưu private key
    with open(f'{filename_prefix}_private.pem', 'wb') as f:
        f.write(private_key)

    # Lưu public key
    with open(f'{filename_prefix}_public.pem', 'wb') as f:
        f.write(public_key)

    print(f'Đã tạo khóa cho {filename_prefix}!')

# Sinh khóa cho sender
generate_rsa_keypair('sender')

# Sinh khóa cho receiver
generate_rsa_keypair('receiver')
