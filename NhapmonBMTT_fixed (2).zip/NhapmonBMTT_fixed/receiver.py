# receiver.py
import base64
import sqlite3  # Thêm dòng import này
import cryptoUtils as crypto

# Load các khóa RSA
receiver_priv = open('receiver_private.pem', 'rb').read()
sender_pub = open('sender_public.pem', 'rb').read()

# Đọc khóa TripleDES đã được mã hóa RSA
with open("encrypted_3des_key.bin", "rb") as f:
    encrypted_3des_key = f.read()

# Giải mã khóa TripleDES
triple_des_key = crypto.decrypt_with_rsa(receiver_priv, encrypted_3des_key)
print(f"Khóa TripleDES đã giải mã (hex): {triple_des_key.hex()}")

# Đọc message cuối cùng từ DB
conn = sqlite3.connect(crypto.DB_NAME)
c = conn.cursor()
c.execute("SELECT id, iv, cipher, hash, sig FROM messages ORDER BY id DESC LIMIT 1")
msg = c.fetchone()
conn.close()

if not msg:
    print("Không tìm thấy message trong DB!")
    exit()

# Giải mã các trường từ DB
msg_id = msg[0]
iv_db = base64.b64decode(msg[1])
cipher_db = base64.b64decode(msg[2])
hash_db = msg[3]
sig_db = base64.b64decode(msg[4])

# Kiểm tra tính toàn vẹn
calculated_hash = crypto.sha256_hash(iv_db, cipher_db)
if calculated_hash != hash_db:
    print("Lỗi: Tính toàn vẹn message bị vi phạm!")
    exit()

# Kiểm tra chữ ký
if not crypto.verify_signature(sender_pub, cipher_db, sig_db):  # Sửa lỗi chính tả verify_signature
    print("Lỗi: Chữ ký không hợp lệ!")
    exit()

# Giải mã message
plaintext = crypto.decrypt_triple_des(triple_des_key, iv_db, cipher_db)

try:
    print(f"Message ID {msg_id} đã giải mã:", plaintext.decode('utf-8'))
    print("ACK")  # Xác nhận thành công
except UnicodeDecodeError:
    print("Lỗi: Không thể giải mã message!")
    print("NACK")